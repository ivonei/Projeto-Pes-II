<?php

require('carro.class.php');

$subcar = new subClasse();
/*$car = new carro();*/

$car->nome = "Fiorino";
$car->modelo = "Furacao";
echo "{$car->nome}";

?>